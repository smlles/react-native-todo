

const ClientId = "IaEq_srSMroT6vVkU9Zj"
const ClientSecret="vsnTkhhA9H"

export {ClientId,ClientSecret}