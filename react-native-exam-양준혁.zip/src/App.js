import { TextInput,Pressable,Text, View,StyleSheet } from "react-native"
import SignupScreen from "./Components/SignupScreen"

const App =()=>{

  return(
   <SignupScreen/>
  )
}

export default App;